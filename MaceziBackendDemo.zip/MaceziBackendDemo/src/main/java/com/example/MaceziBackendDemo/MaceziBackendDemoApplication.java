package com.example.MaceziBackendDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MaceziBackendDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MaceziBackendDemoApplication.class, args);
	}

}
